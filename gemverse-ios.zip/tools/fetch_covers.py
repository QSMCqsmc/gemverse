#!/usr/bin/env python3
"""缓存官方封面小图，供单文件 HTML 离线显示。无需音频下载。"""
import json,pathlib,urllib.request,concurrent.futures,base64
root=pathlib.Path(__file__).resolve().parents[1]
catalog=json.loads((root/'data/catalog.json').read_text());path=root/'data/covers.json'
covers=json.loads(path.read_text()) if path.exists() else {}
tasks={}
for platform in ['apple','netease']:
 for s in catalog[platform]:
  key=f"{platform}:{s['id'] if s['albumId']=='0' else s['albumId']}"
  if key not in tasks and key not in covers and s['artwork']:
   tasks[key]=s['artwork']+('?param=120y120' if platform=='netease' else '')
def fetch(task):
 key,url=task
 try:
  with urllib.request.urlopen(url,timeout=15) as r:
   mime=r.headers.get_content_type();b=r.read()
   if mime.startswith('image/') and len(b)<150000:return key,'data:'+mime+';base64,'+base64.b64encode(b).decode()
 except Exception:pass
 return key,None
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
 for key,data in pool.map(fetch,tasks.items()):
  if data:covers[key]=data
path.write_text(json.dumps(covers,separators=(',',':')))
print('Cached covers',len(covers),'of',len(covers)+len([x for x in tasks if x not in covers]))
