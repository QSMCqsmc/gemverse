"""Choose one representative recording per song, preserving raw source records."""
import re,unicodedata
VERSION=r'live|remix|mix|acoustic|instrumental|伴奏|纯音乐|重生|周年|热爱版|现场|钢琴版|piano session|version|电影|主题曲|片尾|with |feat\.?|ft\.?'
ALIASES={'再见goodbye':'再见','我的秘密mysecret':'我的秘密','回忆的沙漏hourglass':'回忆的沙漏','睡公主sleepingbeauty':'睡公主','塞纳河seineriver':'塞纳河','想讲你知gottasayit':'想讲你知','mascara烟熏妆':'烟熏妆','mascara':'烟熏妆','寂寞星球的玫瑰therose':'寂寞星球的玫瑰','奇迹miracle':'奇迹','美好的旧时光inmyheart':'美好的旧时光','thevoicewithin遗失的声音':'thevoicewithin','爱你ainy2017':'ainy','多远也要在一起':'多远都要在一起','泡沫bubble':'泡沫','ainy爱你':'ainy','爱你':'ainy','allaboutyou':'allaboutu','wheredidyougo':'wheredidugo','情人lover':'情人','潜意式的残酷':'潜意识的残酷','gem':'gemgeteverybodymoving','sleepingbeauty睡公主英文版':'睡公主'}
def normalize(s,charmap):
 s=''.join(charmap.get(c,c) for c in unicodedata.normalize('NFKC',s)).lower()
 return ''.join(c for c in s if c.isalnum())
def song_key(song,charmap):
 name=''.join(charmap.get(c,c) for c in unicodedata.normalize('NFKC',song['name']))
 # Strip version annotations, never arbitrary meaningful title subtitles.
 name=re.sub(r'\([^()]*\)|\[[^\[\]]*\]',lambda m:'' if re.search(VERSION,m[0],re.I) else m[0],name)
 name=re.sub(r'\s+-\s+(?:live|.*remix|.*mix|instrumental|acoustic).*$', '',name,flags=re.I)
 name=re.sub(r'(Where\s+Did\s+(?:U|You)\s+Go)\s*2\.0',r'\1',name,flags=re.I)
 key=normalize(name,charmap)
 return ALIASES.get(key,key)
def preference(song):
 n=song['name'].lower();album=song['album'].lower();both=n+' '+album
 # Bare titles on televised concert albums are still live recordings.
 score=0
 if re.search(r'live|concert|现场|演唱会|晚会|歌手|音乐会|我想和你唱|音乐公告牌|新说唱|盖世英雄|金曲捞|唱起来|下一站传奇|明日之子|王牌对王牌|热门华语|最新热歌',both):score+=80
 if re.search(r'remix|club mix|dance mix|dub mix',both):score+=100
 if re.search(r'伴奏|纯音乐|instrumental',both):score+=200
 if re.search(r'重生|周年|i am gloria',both):score+=35
 if re.search(r'acoustic|热爱版',both):score+=50
 if re.search(r'best of|精选|deluxe|18 plus',album):score+=15
 if 'single' in album:score+=1
 return score,song.get('date') or '9999',song['id']
def dedupe(songs,charmap):
 groups={}
 for song in songs:
  if re.search(r'[+＋]|\s/\s|组曲|組曲|串烧',song['name']):continue
  groups.setdefault(song_key(song,charmap),[]).append(song)
 chosen=[dict(min(group,key=preference),workKey=key) for key,group in groups.items()]
 aliases={s['id']:min(group,key=preference)['id'] for group in groups.values() for s in group}
 return chosen,aliases,groups
