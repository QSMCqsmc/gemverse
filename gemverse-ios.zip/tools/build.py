#!/usr/bin/env python3
"""生成可单独打开的 index.html；无需 Node、安装依赖或运行后端。"""
import json,pathlib,sys
root=pathlib.Path(__file__).resolve().parents[1]
catalog=json.loads((root/'data/catalog.json').read_text())
assert len(catalog['apple'])>16 and len(catalog['netease'])>16
for key in ['apple','netease']:
 assert len({s['id'] for s in catalog[key]})==len(catalog[key])
 for s in catalog[key]:
  assert s['id'].isdigit() and s['albumId'].isdigit()
  assert s['name'] and s['album']
  assert s['artistId']==425208570 or any(n in s['artist'] for n in ['邓紫棋','鄧紫棋']) if key=='apple' else 7763 in s['artistIds']
coverfile=root/'data/covers.json'
covers=json.loads(coverfile.read_text()) if '--offline-covers' in sys.argv and coverfile.exists() else {}
def inline(d):return json.dumps(d,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c')
charmap={}
for line in (root/'tools/TSCharacters.txt').read_text().splitlines():
 if line and not line.startswith('#') and '\t' in line:
  key,values=line.split('\t',1);charmap[key]=values.split()[0]
html=(root/'tools/page.html').read_text().replace('__POPULARITY__',inline(json.loads((root/'data/popularity.json').read_text()))).replace('__CATALOG__',inline(catalog)).replace('__COVERS__',inline(covers)).replace('__CHARMAP__',inline(charmap))
(root/'index.html').write_text(html)
print('Built',root/'index.html',len(html.encode()),'bytes')
