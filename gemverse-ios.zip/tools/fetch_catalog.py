#!/usr/bin/env python3
"""从平台官方只读目录获取数据；不抓取或下载音频。Python 3 标准库即可运行。"""
import hashlib,json,urllib.request,urllib.parse,time,concurrent.futures,datetime,pathlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
CACHE=ROOT/'data'/'raw';CACHE.mkdir(parents=True,exist_ok=True)
errors=[]
def get(url,key):
 p=CACHE/(key+'.json')
 if p.exists(): return json.loads(p.read_text())
 for attempt in range(2):
  try:
   with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0','Referer':'https://music.163.com/'}),timeout=25) as r:d=json.load(r)
   p.write_text(json.dumps(d,ensure_ascii=False));return d
  except Exception as e:
   if attempt: errors.append({'url':url,'error':str(e)});return {}
   time.sleep(1)
def apple_albums(country):
 d=get('https://itunes.apple.com/lookup?'+urllib.parse.urlencode({'id':425208570,'entity':'album','limit':200,'country':country}),'apple-albums-'+country)
 return [x['collectionId'] for x in d.get('results',[]) if x.get('wrapperType')=='collection']
def apple_tracks(args):
 country,ids=args
 return country,get('https://itunes.apple.com/lookup?'+urllib.parse.urlencode({'id':','.join(map(str,ids)),'entity':'song','limit':200,'country':country}),'apple-tracks-'+country+'-'+hashlib.sha256(','.join(map(str,ids)).encode()).hexdigest()[:16])
def ne_tracks(album):
 return album,get(f'https://music.163.com/api/album/{album}','netease-album-'+str(album))
def main():
 albums={}
 for region in ['cn','hk','tw']:
  albums[region]=apple_albums(region)
  print(region,'albums',len(albums[region]),flush=True)
 tasks=[(c,ids[i:i+12]) for c,ids in albums.items() for i in range(0,len(ids),12)]
 apple={}
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
  for country,d in pool.map(apple_tracks,tasks):
   for s in d.get('results',[]):
    if s.get('kind')!='song' or not (s.get('artistId')==425208570 or any(n in s.get('artistName','') for n in ['鄧紫棋','邓紫棋'])):continue
    sid=s['trackId']
    if sid in apple:
     apple[sid]['regions'].append(country);continue
    apple[sid]={'id':str(sid),'name':s['trackName'],'album':s['collectionName'],'albumId':str(s['collectionId']),'artist':s['artistName'],'artistId':s['artistId'],'artwork':s.get('artworkUrl100','').replace('100x100bb','160x160bb'),'date':s.get('releaseDate','')[:10],'duration':s.get('trackTimeMillis',0),'trackNumber':s.get('trackNumber',0),'url':s['trackViewUrl'],'preview':s.get('previewUrl',''),'country':country,'regions':[country]}
 ne_albums=get('https://music.163.com/api/artist/albums/7763?offset=0&limit=100','netease-albums')
 assert ne_albums.get('artist',{}).get('id')==7763
 netease={}
 # 歌手全部歌曲接口分页；专辑详情接口可能要求账号验证，不依赖该接口。
 ne_songs=[]
 for offset in [0,200,400]:
  d=get(f'https://music.163.com/api/v1/artist/songs?id=7763&order=time&offset={offset}&limit=1000','netease-songs-v2-'+str(offset))
  if d.get('code')!=200:
   errors.append({'platform':'netease','offset':offset,'code':d.get('code'),'message':d.get('message','')});break
  ne_songs.extend(d.get('songs',[]))
  if not d.get('more'):break
 for s in ne_songs:
  artists=s.get('artists',s.get('ar',[]))
  if not any(x.get('id')==7763 for x in artists):continue
  al=s.get('album',s.get('al',{}));sid=s['id'];t=al.get('publishTime',0)
  netease[sid]={'id':str(sid),'name':s['name'],'album':al.get('name') or '专辑信息未提供','albumId':str(al.get('id','')),'artist':' / '.join(a['name'] for a in artists),'artistIds':[a['id'] for a in artists],'artwork':al.get('picUrl',''),'date':datetime.datetime.fromtimestamp(t/1000,datetime.timezone.utc).date().isoformat() if t else '', 'duration':s.get('duration',s.get('dt',0)),'trackNumber':s.get('no',0),'fee':s.get('fee',0),'status':s.get('status',0),'url':f'https://music.163.com/song?id={sid}'}
 catalog={'updated':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).date().isoformat(),'artist':{'apple':'425208570','netease':'7763'},'apple':list(apple.values()),'netease':list(netease.values()),'albumCounts':{**{f'apple-{k}':len(v) for k,v in albums.items()},'netease':len(ne_albums.get('hotAlbums',[]))},'errors':errors,'sources':{'apple':'https://itunes.apple.com/lookup?id=425208570&entity=album&country=hk&limit=200','netease':'https://music.163.com/api/v1/artist/songs?id=7763&order=time&offset=0&limit=200'},'notes':['Apple 中国大陆 iTunes 接口此次只返回专辑信息，没有返回单曲；曲目来自香港和台湾商店。','网易云专辑详情接口要求账号验证，改用官方歌手全部歌曲分页目录；无需登录。']}
 if len(apple)<17 or len(netease)<17:raise RuntimeError('官方目录本次获取不完整，保留原 catalog.json，不覆盖。')
 (ROOT/'data'/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2))
 print('TRACKS',len(apple),len(netease),'ERRORS',len(errors),flush=True)
if __name__=='__main__':main()
