#!/usr/bin/env python3
"""Cache attributed third-party Spotify stream statistics; never infer missing counts."""
import json,re,urllib.request,html,pathlib,sys
root=pathlib.Path(__file__).resolve().parents[1]
url='https://kworb.net/spotify/artist/7aRC4L63dBn3CiLDuWaLSI_songs.html'
raw=pathlib.Path(sys.argv[1]).read_text() if len(sys.argv)>1 else urllib.request.urlopen(url,timeout=30).read().decode()
updated=re.search(r'Last updated: (\d{4}/\d{2}/\d{2})',raw).group(1).replace('/','-')
tracks=[]
for row in re.findall(r'<tr>(.*?)</tr>',raw,re.S):
 match=re.search(r'<a href="(https://open.spotify.com/track/[^"]+)"[^>]*>(.*?)</a>',row,re.S)
 cells=re.findall(r'<td[^>]*>(.*?)</td>',row,re.S)
 if match and len(cells)>=2:
  count=re.sub('<[^>]+>','',cells[1]).replace(',','').strip()
  if count.isdigit():tracks.append({'name':html.unescape(re.sub('<[^>]+>','',match[2])),'streams':int(count),'url':match[1]})
assert len(tracks)>100
(root/'data/popularity.json').write_text(json.dumps({'source':'Kworb','metric':'Spotify cumulative streams','updated':updated,'url':url,'tracks':tracks},ensure_ascii=False,separators=(',',':')))
print('Popularity snapshot:',updated,len(tracks),'tracks')
